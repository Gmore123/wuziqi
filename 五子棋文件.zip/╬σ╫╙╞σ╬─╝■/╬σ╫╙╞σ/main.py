import pygame
from tkinter import messagebox

EMPTY = 0
BLACK = 1
WHITE = 2

black_color = [0, 0, 0]
white_color = [255, 255, 255]


class Point(object):
    def __init__(self, x, y):
        self._x = x
        self._y = y

    def __add__(self, other):
        return Point(self._x + other._x, self._y + other._y)


class RenjuBoard(object):
    def __init__(self):
        self._board = [[]] * 15#记录棋子状态
        self.reset()

    def check(self, y, x, flag):
        # 搜索的区域范围，是以当前的点为中心的9*9的点阵范围
        leftEdge = x - 5
        rightEdge = x + 5
        topEdge = y - 5
        bottomEdge = y + 5

        # 棋盘边界优化处理，缩小搜索范围
        if leftEdge < 0:
            leftEdge = 0
        if rightEdge > 14:
            rightEdge = 14
        if topEdge < 0:
            topEdge = 0
        if bottomEdge > 14:
            bottomEdge = 14

        dirs = [#方向定位
            Point(0, 1),
            Point(1, 1),
            Point(1, 0),
            Point(1, -1),
            Point(0, -1),
            Point(-1, -1),
            Point(-1, 0),
            Point(-1, 1)
        ]
        length = [0] * 8
        for i in range(8):#计算方向上的黑色或白色棋子数
            l = 0
            pos = Point(x, y)
            while self._board[pos._y][pos._x] == flag:
                pos += dirs[i]
                l += 1
                if pos._x < leftEdge or pos._x > rightEdge or pos._y < topEdge or pos._y > bottomEdge:
                    break
            length[i] = l

        for i in range(4):#判定是否有五子成线的情况
            total = length[i] + length[i + 4] - 1
            if total >= 5:
                return True
        return False

    def reset(self):#初始化列表，每格状态均为空
        for row in range(len(self._board)):
            self._board[row] = [EMPTY] * 15

    def move(self, row, col, is_black):#判定格子状态为空，才能下子
        if self._board[row][col] == EMPTY:
            self._board[row][col] = BLACK if is_black else WHITE
            return True
        return False

    def draw(self, screen):#绘制棋盘
        for index in range(1, 16):#话棋盘的线
            pygame.draw.line(screen, black_color,
                             [40, 40 * index], [600, 40 * index], 1)
            pygame.draw.line(screen, black_color,
                             [40 * index, 40], [40 * index, 600], 1)
        pygame.draw.rect(screen, black_color, [36, 36, 568, 568], 4)
        #画出常见的棋盘上的五个黑点点
        pygame.draw.circle(screen, black_color, [320, 320], 5, 0)
        pygame.draw.circle(screen, black_color, [160, 160], 5, 0)
        pygame.draw.circle(screen, black_color, [480, 480], 5, 0)
        pygame.draw.circle(screen, black_color, [480, 160], 5, 0)
        pygame.draw.circle(screen, black_color, [160, 480], 5, 0)
        for row in range(len(self._board)):
            for col in range(len(self._board[row])):
                if self._board[row][col] != EMPTY:
                    ccolor = black_color \
                        if self._board[row][col] == BLACK else white_color
                    pos = [40 * (col + 1), 40 * (row + 1)]
                    pygame.draw.circle(screen, ccolor, pos, 20, 0)


def main():
    board = RenjuBoard()
    is_black = True
    pygame.init()
    pygame.display.set_caption('五子棋')
    screen = pygame.display.set_mode([640, 640])
    screen.fill([255, 255, 0])
    board.draw(screen)
    pygame.display.flip()
    running = True
    while running:#监听鼠标，查看鼠标点在那里
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYUP:
                pass
            elif event.type == pygame.MOUSEBUTTONDOWN \
                    and event.button == 1:
                x, y = event.pos
                row = round((y - 40) / 40)
                col = round((x - 40) / 40)
                if board.move(row, col, is_black):
                    is_black = not is_black
                    screen.fill([255, 255, 0])
                    board.draw(screen)
                    pygame.display.flip()
                if board.check(row, col, board._board[row][col]):
                    if board._board[row][col] == BLACK:
                        messagebox.showinfo("提示", "黑色方胜利！")
                        pygame.quit()
                    else:
                        messagebox.showinfo("提示", "白色方胜利！")
                        pygame.quit()
    pygame.quit()


if __name__ == '__main__':
    main()
